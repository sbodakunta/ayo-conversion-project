package com.ayo.demo.service.convertor;

public enum ConversionType {
    TEMPERATURE,
    AREA,
    LENGTH,
    VOLUME,
    WEIGHT
}
