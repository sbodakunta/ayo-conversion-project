package com.ayo.demo.service.convertor;

public interface Convertor {

    double convertToMetric(double fromValue);

    double convertToImperial(double fromValue);
}
