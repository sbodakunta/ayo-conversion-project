package com.ayo.demo.service.convertor;

public enum SystemType {
    IMPERIAL,
    METRIC
}
